#pragma once
#include <unordered_map>
#include "BusManager.h"
#include "graph.h"
#include "route.h"
#include <memory>
using Indexes = std::unordered_map<Stop, size_t>;



struct GraphBuilder {
	struct SInfo {
		std::string stop;
		size_t index;
	};

	Indexes AddOuterVertexIndexes(const std::unordered_map<Stop, StopInfo>& stops, const BusManager& manager);
	void AddInnerIndexesForBusLoopingRoute(const std::string& bus, const std::vector<std::string>& stops,
		const BusManager& manager);
	void AddInnerIndexesForBusStrightRoute(const std::string& bus, const std::vector<std::string>& stops,
		const BusManager& manager);

	std::vector<Graph::Edge<Weight>> AddLoopingRoute(std::string bus, const BusManager& manager);

	std::vector<Graph::Edge<Weight>> AddStrightRoute(std::string bus, const BusManager& manager);

	std::vector<Graph::Edge<Weight>> AddOuterAndInnerEdgesForLoopingRoute(std::string bus, const BusManager& manager);
	std::vector<Graph::Edge<Weight>> AddOuterAndInnerEdgesForStrightRoute(std::string bus, const BusManager& manager);

	size_t GetNewVertexIndex();

	std::unordered_map<std::string, std::vector<SInfo>> inner_indexes_for_bus_route;
	Indexes outer_indexes;
	size_t vertex_count = 0;
};
std::shared_ptr<Graph::DirectedWeightedGraph<Weight>> BuildGraph(const BusManager& manager);
Graph::Edge<Weight> AddEdge(size_t from, size_t to, Weight weight);
