#include "GraphBuilder.h"

namespace GB {

	bool operator<(const Weight& lhs, const Weight& rhs) {
		return lhs.weight < rhs.weight;
	}
	bool operator>(const Weight& lhs, const Weight& rhs) {
		return lhs.weight > rhs.weight;
	}
	Weight operator+(const Weight& lhs, const Weight& rhs) {
		return { lhs.weight + rhs.weight };
	}
	bool operator>=(const Weight& lhs, int rhs) {
		return lhs.weight >= rhs;
	}


	Graph::Edge<Weight> AddEdge(size_t from, size_t to, Weight weight) {
		return Graph::Edge<Weight>{
			.from = from,
			.to = to,
			.weight = weight
		};
	}


	size_t GraphBuilder::GetNewVertexIndex() {
		return vertex_count++;
	}


	Indexes GraphBuilder::AddOuterVertexIndexes(const std::unordered_map<Stop, StopInfo>& stops_,
		const BusManager& manager) {
		for (const auto& [stop, stop_info] : stops_) {
			outer_indexes[stop] = GetNewVertexIndex();
			manager.AddOuterStopIndex(stop, outer_indexes[stop]);
		}
		return outer_indexes;
	}
	void GraphBuilder::AddInnerIndexesForBusLoopingRoute(const std::string& bus, const std::vector<std::string>& stops,
		const BusManager& manager) {
		for (auto stop = stops.begin(); stop !=stops.end(); ++stop) {
			inner_indexes_for_bus_route[bus].push_back({ *stop, GetNewVertexIndex() });
			manager.AddStopIndex(*stop, inner_indexes_for_bus_route[bus].back().index);
		}
	}
	void GraphBuilder::AddInnerIndexesForBusStrightRoute(const std::string& bus, const std::vector<std::string>& stops,
		const BusManager& manager) {
		for (const auto& stop : stops) {
			inner_indexes_for_bus_route[bus].push_back({ stop, GetNewVertexIndex() });
			manager.AddStopIndex(stop, inner_indexes_for_bus_route[bus].back().index);

		}
	}
	std::vector<Graph::Edge<Weight>> GraphBuilder::AddOuterAndInnerEdgesForStrightRoute(std::string bus, const BusManager& manager) {
		std::vector<Graph::Edge<Weight>> edges;
		auto& stops = inner_indexes_for_bus_route[bus];
		edges.reserve(stops.size() * 2);
		for (const auto& [stop, stop_index] : stops) {
			edges.push_back(AddEdge(outer_indexes[stop], stop_index, 
				{ static_cast<double>(manager.GetSettings().bus_wait_time), "" }));
			edges.push_back(AddEdge(stop_index, outer_indexes[stop], { 0.0, "" }));
		}
		return edges;
	}
	std::vector<Graph::Edge<Weight>> GraphBuilder::AddOuterAndInnerEdgesForLoopingRoute(std::string bus, const BusManager& manager) {
		std::vector<Graph::Edge<Weight>> edges;
		auto& stops = inner_indexes_for_bus_route[bus];
		edges.reserve(stops.size());
		for (size_t i = 0; i < stops.size() - 1; ++i) {
			edges.push_back(AddEdge(outer_indexes[stops[i].stop], stops[i].index,
				{ static_cast<double>(manager.GetSettings().bus_wait_time), "" }));
			edges.push_back(AddEdge(stops[i].index, outer_indexes[stops[i].stop], { 0.0, "" }));
		}
		edges.push_back(AddEdge(stops.back().index, outer_indexes[stops.back().stop], { 0, "" }));
		return edges;
	}

	std::vector<Graph::Edge<Weight>> GraphBuilder::AddLoopingRoute(std::string bus, const BusManager& manager) {
		std::vector<Graph::Edge<Weight>> edges;
		auto& stops = inner_indexes_for_bus_route[bus];
		edges.reserve(stops.size());
		for (size_t i = 0; i < stops.size() - 1; ++i) {
			edges.push_back(AddEdge(stops[i].index, stops[i + 1].index, 
				{ manager.GetDistanceBtwStops(stops[i].stop, stops[i + 1].stop) / manager.GetSettings().bus_velocity, bus }));
		}
		return edges;
	}

	std::vector<Graph::Edge<Weight>> GraphBuilder::AddStrightRoute(std::string bus, const BusManager& manager) {
		std::vector<Graph::Edge<Weight>> edges;
		auto& stops = inner_indexes_for_bus_route[bus];
		edges.reserve(stops.size() * 2);
		for (size_t i = 0; i < stops.size() - 1; ++i) {
			edges.push_back(AddEdge(stops[i].index, stops[i + 1].index,
				{ manager.GetDistanceBtwStops(stops[i].stop, stops[i + 1].stop) / manager.GetSettings().bus_velocity, bus }));
		}
		for (size_t i = stops.size(); i > 1; --i) {
			edges.push_back(AddEdge(stops[i - 1].index, stops[i - 2].index,
				{ manager.GetDistanceBtwStops(stops[i - 1].stop, stops[i - 2].stop) / manager.GetSettings().bus_velocity, bus }));
		}
		return edges;
	}

	Graph::DirectedWeightedGraph<Weight> BuildGraph(const BusManager& manager) {
		GraphBuilder builder;
		auto outer_indexes = builder.AddOuterVertexIndexes(manager.GetStops(), manager);
		std::vector<std::vector<Graph::Edge<Weight>>> edges;
		for (const auto& [bus, bus_info] : manager.GetBuses()) {
			if (bus_info.type == RouteType::LOOPING) {
				builder.AddInnerIndexesForBusLoopingRoute(bus, bus_info.route, manager);
				edges.push_back(builder.AddOuterAndInnerEdgesForLoopingRoute(bus, manager));
				edges.push_back(builder.AddLoopingRoute(bus, manager));
			}
			else {
				builder.AddInnerIndexesForBusStrightRoute(bus, bus_info.route, manager);
				edges.push_back(builder.AddOuterAndInnerEdgesForStrightRoute(bus, manager));
				edges.push_back(builder.AddStrightRoute(bus, manager));
			}
		}
		Graph::DirectedWeightedGraph<Weight> graph(builder.vertex_count);
		for (const auto& route_edges : edges) {
			for (const auto& edge : route_edges) {
				graph.AddEdge(edge);
			}
		}
		return graph;
	}
}