#pragma once
#include <vector>
#include "Request.h"

std::vector<ResponseHolder> ProcessRequests(const std::vector<RequestHolder>& requests);
